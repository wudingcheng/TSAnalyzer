#!/usr/bin/env python
# -*- coding: utf-8 -*-

from .window import main
